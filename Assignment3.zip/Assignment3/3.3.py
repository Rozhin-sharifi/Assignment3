import random

num=[]
nonrep_num=[]


while len(nonrep_num)<11:
    num=random.randint(0,100)
    if num not in nonrep_num:
        nonrep_num.append(num)
print(nonrep_num)