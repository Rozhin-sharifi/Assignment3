list = []
n = int(input("Enter number of elements : ")) 
for i in range(0, n):
    ele = int(input())
    list.append(ele)
print(list)
if list==sorted(list):
    print('yes it is sorted')
else:
    print('no it is sorted')


