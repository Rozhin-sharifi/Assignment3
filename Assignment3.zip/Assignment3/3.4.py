text = input('please enter your text: ')
words = text.split()
print('Number of words in text :', len(words))