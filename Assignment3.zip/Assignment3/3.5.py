x=int(input('please enter a number\n'))
i = 1
while True:       
    if x % i == 0:
        x //= i        
    else:
        break      
    i += 1
if x == 1:
    print('factorial number')
else:
    print('not factorial number')